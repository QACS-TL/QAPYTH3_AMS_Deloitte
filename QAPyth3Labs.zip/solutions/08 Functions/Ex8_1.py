#! /usr/bin/python

def myfunc1(val, lista = []):
    lista.append(val)
    print("value of lista is:", lista)
    
myfunc1(42)
myfunc1(37)
myfunc1(99)


# def myfunc2(val=100, lista=None):
#     if lista == None: lista = []
#
#     lista.append(val)
#     print("value of lista is:", lista)
#     return
#
# listx = []
# num = int(input("Please enter a number, -1 to quit"))
# while num != -1:
#     myfunc2(num, listx)
#     num = int(input("Please enter a number, -1 to quit"))
#
# myfunc2(lista=listx)
# myfunc2(37, listx)
# myfunc2(99)

