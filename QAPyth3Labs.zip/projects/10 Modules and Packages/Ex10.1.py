import timer
# from timer import start_timer, end_timer

timer.start_timer()
lines = 0
for row in open ("words"):
    lines += 1
    
timer.end_timer()
print ("Number of lines:",lines)