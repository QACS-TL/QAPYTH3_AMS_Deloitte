import sys
import glob
import os

# Get the directory name.
if sys.platform == 'win32':
    hdir = os.environ['HOMEPATH']
else:
    hdir = os.environ['HOME']

# Construct a portable wildcard pattern.
pattern = os.path.join(hdir, '*')
pattern = "C:\\" + pattern # Extra Line Needed in filepath for code to work
# TODO: Use the glob.glob() function to obtain the list of filenames.
for filename in glob.glob(pattern):
    size = os.path.getsize(filename)
    # TODO: Use os.path.getsize to find each file's size.
    # print(f"{filename} is {size} bytes in size")

    # TODO: Add a test to only display files that are not zero length.
    # if size > 0:
    #     print(f"{filename} is {size} bytes in size")

    #TODO: Remove the leading directory name(s) from each filename before you print it -
    # using os.path.basename()
    if size > 0:
        print(f"{os.path.basename(filename)} is {size} bytes in size")
